﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;

namespace WCF4_CachingApplicationBlock_EntLib5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// This article is written for DotNetCurry.com
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<Employee> lstEmp = 
            new ObservableCollection<Employee> ();

        public ObservableCollection<Employee> LstEmp
        {
            get { return lstEmp; }
            set { lstEmp = value; }
        }

        //Declaration for Cache Status
        string status = string.Empty;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
        }


        private void lstEmpName_SelectionChanged(object sender, 
            SelectionChangedEventArgs e)
        {
            if (lstEmp.Count >0)
            {
                int Eno = Convert.ToInt32(lstEmpName.SelectedValue);
                Employee Emp = CachingInfrastructure
                                    .GetEmployeeByEmpNo(Eno, out status);
                txteno.Text = Emp.EmpNo.ToString();
                txtename.Text = Emp.EmpName;
                txtsal.Text = Emp.Salary.ToString();
                txtdno.Text = Emp.DeptNo.ToString();
                txtCacheStatus.Text = status;
            }
        }

        private void btnLoadData_Click(object sender, RoutedEventArgs e)
        {
            if (lstEmp.Count == 0)
            {
                lstEmp = CachingInfrastructure.GetEmployeeData(out status);
                lstEmpName.ItemsSource = lstEmp;
                lstEmpName.DisplayMemberPath = "EmpName";
                lstEmpName.SelectedValuePath = "EmpNo";
                txtCacheStatus.Text = status;
                lstEmpName.SelectionChanged += 
                    new SelectionChangedEventHandler(lstEmpName_SelectionChanged);
            }
        }

        private void btnClearCache_Click(object sender, RoutedEventArgs e)
        {
            CachingInfrastructure.ClearCache(out status);
            txtCacheStatus.Text = status;

            lstEmp.Clear(); 

            txteno.Text = "";
            txtename.Text = "";
            txtsal.Text = "";
            txtdno.Text="";
            lstEmp.Clear(); 
        }
    }
}

This source code is explained at

http://www.dotnetcurry.com/ShowArticle.aspx?ID=670
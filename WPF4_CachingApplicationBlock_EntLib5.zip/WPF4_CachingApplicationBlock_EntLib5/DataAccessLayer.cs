﻿using System;
using System.Data.SqlClient;
using System.Collections.ObjectModel;

namespace WCF4_CachingApplicationBlock_EntLib5
{
    public class Employee
    {
        public int EmpNo { get; set; }
        public string EmpName { get; set; }
        public int Salary { get; set; }
        public int DeptNo { get; set; }
    }

    public class DataAccess
    {
        SqlConnection Conn;
        SqlCommand Cmd;
        SqlDataReader Reader;

        public DataAccess()
        {
            Conn = new SqlConnection("Data Source=.;Initial Catalog=Company;Integrated Security=SSPI"); 
        }

        public ObservableCollection<Employee> GetmEployees()
        {
            ObservableCollection<Employee> lstEmployees = new ObservableCollection<Employee>();
            Conn.Open();
            Cmd = new SqlCommand();
            Cmd.Connection = Conn;
            Cmd.CommandText = "Select * from Employee";
            Reader = Cmd.ExecuteReader();
            while (Reader.Read())
            {
                lstEmployees.Add(new Employee()
                {
                    EmpNo = Convert.ToInt32(Reader["EmpNo"]),
                    EmpName = Reader["EmpName"].ToString(),
                    Salary = Convert.ToInt32(Reader["Salary"]),
                    DeptNo = Convert.ToInt32(Reader["DeptNo"]),
                }
                );
            }
            Reader.Close();
            Conn.Close();
            return lstEmployees;
        }
    }
}

﻿using System;
using System.Linq;
using Microsoft.Practices.EnterpriseLibrary.Caching;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Caching.Expirations;
using System.Collections.ObjectModel;

namespace WCF4_CachingApplicationBlock_EntLib5
{
    public class CachingInfrastructure
    {

        static ObservableCollection<Employee> lstEmployee = null;
        static ICacheManager cacheEmployeeData;
        static bool CacheFlag = false;
        public CachingInfrastructure()
        {

        }

        /// <summary>
        /// Get the Employee Data. Initially Try to get it from Cache, 
        /// If not available then access it from DataAccessLayer and put it in Cache
        /// </summary>
        /// <param name="cacheStatus"></param>
        /// <returns></returns>
        public static ObservableCollection<Employee> GetEmployeeData(out string cacheStatus)
        {
            //Try to Retrieve data from Cache
          cacheEmployeeData = EnterpriseLibraryContainer.Current.GetInstance<ICacheManager>();

          lstEmployee = (ObservableCollection<Employee>)cacheEmployeeData["EmployeeDataCache"];
            cacheStatus = "Employee Information is Retrived from Cache";
            CacheFlag = true;
            //If Nothing is retrived from Cache then Get it from Data Access Layer class

            if (lstEmployee == null)
            {
                DataAccess objDs = new DataAccess();
                lstEmployee = objDs.GetmEployees();
                //Define Expiration time for Cache for 2 Minutes
                AbsoluteTime CacheExpiretionTime = new AbsoluteTime(new TimeSpan(0,2,0));
                //Add the Data in Cache
                cacheEmployeeData.Add("EmployeeDataCache", lstEmployee, CacheItemPriority.High, 
                    null, new ICacheItemExpiration[] { CacheExpiretionTime });
                cacheStatus = "Employee Information is Added in Cache";
                CacheFlag = false;
            }

            return lstEmployee;
        }

        public static Employee GetEmployeeByEmpNo(int EmpNo, out string cacheStatus)
        {
            Employee EmpSelected = null;
           
          
                EmpSelected = (from Emp in lstEmployee
                               where Emp.EmpNo == EmpNo
                               select Emp).First();
                cacheStatus = "Employee Information is Retrived from Cache";
                return EmpSelected;
          
        }


        /// <summary>
        /// Method to Clear Cache
        /// </summary>
        public static void ClearCache(out string cachsStatus)
        {
            ICacheManager cacheEmpData = 
                EnterpriseLibraryContainer.Current.GetInstance<ICacheManager>();
            cacheEmpData.Flush();
            cachsStatus = "Cache is Cleared."; 
        }

    }
}
